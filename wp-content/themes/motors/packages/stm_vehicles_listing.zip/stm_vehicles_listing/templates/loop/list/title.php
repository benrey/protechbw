<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>

<div class="title">
    <a href="<?php the_permalink() ?>" class="rmv_txt_drctn">
        <?php the_title(); ?>
    </a>
</div>