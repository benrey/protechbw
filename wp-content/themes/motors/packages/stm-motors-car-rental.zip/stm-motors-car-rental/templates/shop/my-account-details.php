<div class="stm-mcr-account-wrap">
	<?php stm_car_rental_load_template( 'shop/parts/account-navigation' ); ?>
    <div class="woocommerce-MyAccount-wrap woocommerce-MyAccount-content">
		<?php do_action( 'woocommerce_account_content' ); ?>
    </div>
</div>