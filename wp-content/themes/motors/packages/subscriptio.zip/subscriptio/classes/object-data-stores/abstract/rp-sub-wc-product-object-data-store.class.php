<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WooCommerce Product Data Store
 *
 * @class RP_SUB_WC_Product_Object_Data_Store
 * @package Subscriptio
 * @author RightPress
 */
abstract class RP_SUB_WC_Product_Object_Data_Store extends RightPress_WC_Product_Object_Data_Store
{





}
