<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * WordPress Custom Object Data Store Interface
 *
 * @package RightPress
 * @author RightPress
 */
interface RightPress_WP_Custom_Object_Data_Store_Interface
{





}
