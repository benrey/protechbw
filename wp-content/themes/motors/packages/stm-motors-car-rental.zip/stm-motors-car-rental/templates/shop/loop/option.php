<?php
$id = get_the_ID();
$excerpt = get_the_excerpt();
$product = wc_get_product();
$fields = stm_get_rental_order_fields_values();

$price = $product->get_price();
$reg_price = $product->get_regular_price();
$sale_price = $product->get_sale_price();

$cart_items = stm_get_cart_items();

$added = false;
$optQuant = 0;

$singlePay = get_post_meta( $id, '_car_option', true );
$fields['ceil_days'] = ($fields['ceil_days'] == '') ? 1 : $fields['ceil_days'];
$days = (!empty($singlePay)) ? 1 : $fields['ceil_days'];

if ( !empty( $cart_items['options_list'][$id] ) ) {
    $added = true;
    $optQuant = (!empty($cart_items['option_quantity'])) ? $cart_items['option_quantity'][$id] : 0;
    $optQuant = (!empty($singlePay)) ? $optQuant : $optQuant / $fields['ceil_days'];
}

if ( !$added ) {
    $gets = array(
        'add-to-cart' => $id
    );
} else {
    $gets = array(
        'remove-from-cart' => $id
    );
}

$manage_stock = get_post_meta( $id, '_manage_stock', true );
?>


<div class="stm_rental_option">
    <?php if ( has_post_thumbnail() ): ?>
        <div class="image">
            <?php the_post_thumbnail( 'thumbnail' ); ?>
        </div>
    <?php endif; ?>
    <div class="stm_rental_option_content">
        <div class="title">
            <h4>
                <?php the_title(); ?>
                <?php if ( !empty( $excerpt ) ): ?>
                    <div class="opt-info-wrap">
                        <i class="fa fa-info" data-toggle="tooltip" data-placement="top" title="<?php echo esc_html( $excerpt ); ?>"></i>
                    </div>
                <?php endif; ?>
            </h4>
            <div class="price">
                <?php if ( !empty( $sale_price ) ): ?>
                    <div class="sale_price"><?php echo (empty($singlePay)) ? sprintf( esc_html__( '%s/Daily', 'stm_motors_car_rental' ), wc_price( $reg_price ) ) : sprintf( esc_html__( '%s/Single', 'stm_motors_car_rental' ), wc_price( $reg_price ) ); ?></div>
                <?php else: ?>
                    <div class="empty_sale_price"></div>
                <?php endif; ?>
                <div class="current_price heading-font">
                    <?php echo (empty($singlePay)) ? sprintf( esc_html__( '%s/Daily', 'stm_motors_car_rental' ), wc_price( $price ) ) : sprintf( esc_html__( '%s/Single', 'stm_motors_car_rental' ), wc_price( $price ) ); ?>
                </div>
            </div>
        </div>
        <div class="meta">
            <?php if ( $manage_stock == 'yes' ): ?>
                <div class="quantity" data-id="<?php echo esc_attr($id); ?>" data-invis-id="<?php echo esc_attr($__vars['invisId']); ?>" data-price="<?php echo esc_attr($price); ?>" data-days="<?php echo esc_attr($days); ?>">
                    <span class="quantity_actions plus">+</span>
                    <input type="text" step="1" min="0" max="5" name="quantity" value="<?php echo esc_attr($optQuant); ?>" title="Qty" class="input-text qty text" size="4">
                    <span class="quantity_actions minus">-</span>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>