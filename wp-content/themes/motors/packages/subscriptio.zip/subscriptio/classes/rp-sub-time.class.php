<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * Time related methods
 *
 * @class RP_SUB_Time
 * @package Subscriptio
 * @author RightPress
 */
class RP_SUB_Time extends RightPress_Time
{





}
