<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

// Load dependencies
require_once 'abstract/rp-sub-wc-product-object-data-store.class.php';

/**
 * Subscription Product Data Store
 *
 * @class RP_SUB_Subscription_Product_Data_Store
 * @package Subscriptio
 * @author RightPress
 */
class RP_SUB_Subscription_Product_Data_Store extends RP_SUB_WC_Product_Object_Data_Store
{





}
