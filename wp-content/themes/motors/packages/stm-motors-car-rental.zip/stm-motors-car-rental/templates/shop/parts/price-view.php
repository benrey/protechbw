<?php
$id = stm_get_wpml_product_parent_id( get_the_ID() );

if(isset($__vars['product_id'])) {
    $id = stm_get_wpml_product_parent_id( $__vars['product_id'] );
}

$product = wc_get_product( $id );

$fields = stm_get_rental_order_fields_values();
$product_type = 'default';

$checkoutUrl = wc_get_checkout_url();

$cart_items = stm_get_cart_items();
$optTotal = 0;
$singlePay = get_post_meta( $id, '_car_option', true );

if(!empty($cart_items['options'])) {
	foreach ( $cart_items['options'] as $item ) {
		$optTotal = $optTotal + $item['total'];
	}
}

if ( $__vars['is_add_to_cart'] ) {
    if ( !empty( $product ) ):
        if ( $product->is_type( 'variable' ) ):
            $variations = $product->get_available_variations();

            $prices = array();
            if ( !empty( $variations ) ) {
                $max_price = 0;
                $i = 0;
                foreach ( $variations as $variation ) {

                    $varId = $variation['variation_id'];
                    $varProd = wc_get_product($varId);

                    if ( ( !empty( $variation['display_price'] ) || !empty( $variation['display_regular_price'] ) ) and !empty( $variation['variation_description'] ) ) {

                        $gets = array(
                            'add-to-cart' => $id,
                            'product_id' => $id,
                            'variation_id' => $variation['variation_id'],
                        );

                        foreach ( $variation['attributes'] as $key => $val ) {
                            $gets[$key] = $val;
                        }

                        $url = add_query_arg( $gets, $checkoutUrl );

                        $total_price = false;
                        if ( !empty( $fields['order_days'] ) ) {
                            $total_price = $varProd->get_price();
                        }

                        if ( !empty( $total_price ) ) {
                            if ( $max_price < $total_price ) {
                                $max_price = $total_price;
                            }
                        }

						if($fields['order_days'] == 0 && PricePerHour::hasPerHour()) {
                            $total_price = PricePerHour::getPricePerHour($id) * $fields['order_hours'];
						}

                        $prices[] = array(
                            'price' => stm_getDefaultVariablePrice( $id, $i ),
                            'text' => $variation['variation_description'],
                            'total' => $total_price,
                            'url' => $url
                        );
                    }

                    $i++;

                }
            }

            if ( !empty( $prices ) ): ?>
                <div class="stm_rent_prices">
                    <?php
                    $i = 1;

                    foreach ( $prices as $price ): ?>
                        <div class="stm_rent_price price-view-<?php echo esc_attr($i); ?>" data-total-price="<?php echo esc_attr($price['total']); ?>">
                            <div class="total heading-font">
                                <span class="total-price"><?php echo wc_price( $price['total'] + $optTotal ); ?></span>
                                <?php
                                if ( !empty( $price['total'] ) ) {
                                    echo esc_html__( 'Total Price', 'stm_motors_car_rental' );
                                }
                                ?>
                            </div>
                            <div class="pay">
                                <a class="heading-font pay-btn-<?php echo esc_attr($i); ?> <?php echo esc_attr($__vars['disableBtns']);?>"
                                   href="<?php echo (empty($__vars['disableBtns'])) ? esc_url( $price['url'] ) : "#"; ?>" data-url="<?php echo (empty($__vars['disableBtns'])) ? esc_url( $price['url'] ) : "#"; ?>"><?php echo wp_strip_all_tags( $price['text'] ); ?></a>
                            </div>
                        </div>
                    <?php $i++; endforeach; ?>
                </div>
            <?php endif; ?>
        <?php else:
            $price = $product->get_price();

			if($fields['order_days'] == 0 && PricePerHour::hasPerHour()) {
                $price = PricePerHour::getPricePerHour($id) * $fields['order_hours'];
			}

            $gets = array(
                'add-to-cart' => $id,
                'product_id' => $id
            );

            $url = add_query_arg( $gets, $checkoutUrl );

            if ( !empty( $price ) and $url ): ?>
                <div class="stm_rent_prices">
                    <div class="stm_rent_price price-view-1" data-total-price="<?php echo esc_attr($price); ?>">
                        <div class="total heading-font">
                            <span class="total-price"><?php echo wc_price( $price + $optTotal ); ?></span>
                            <?php
                            if ( !empty( $price ) ) {
                                echo esc_html__( 'Total Price', 'stm_motors_car_rental' );
                            }
                            ?>
                        </div>
                        <div class="pay">
                            <a class="heading-font pay-btn-1 <?php echo esc_attr($__vars['disableBtns']);?>" href="<?php echo (empty($__vars['disableBtns'])) ? esc_url( $url ) : "#"; ?>" data-url="<?php echo (empty($__vars['disableBtns'])) ? esc_url( $url ) : "#"; ?>"><?php esc_html_e( 'Pay now', 'stm_motors_car_rental' ); ?></a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif;
} else {
    $prices = get_post_meta( $id, '_price' );
    $price = ( !empty( $prices ) ) ? $prices[0] : 0;
    $orderDays = $fields['order_days'];

    ?>
    <div class="stm_price_info">
        <div class="total_days">
            <?php
			$popupId = $id . rand();
			if(PricePerHour::hasPerHour() || PriceForDatePeriod::hasDatePeriod() || (class_exists('DiscountByDays') && DiscountByDays::hasDiscount($id, $fields['order_days'])) || (class_exists('PriceForQuantityDays') && PriceForQuantityDays::hasFixedPrice($id, $fields['order_days']))) {
				echo '<div class="stm-show-rent-promo-info" data-popup-id="stm-promo-popup-wrap-' . $popupId . '">';
				$orderHours = ( empty( $fields['order_hours'] ) ) ? 0 : $fields['order_hours'];
				echo sprintf( __( '%s Days / %s Hours', 'motors' ), $fields['order_days'], $orderHours );
				echo '</div>';
				stm_getPopupPromoPrice( $popupId, $id, $price, $fields);
			} else {
				echo sprintf( esc_html__( 'Total %s %s', 'stm_motors_car_rental' ), $orderDays, ( $orderDays < 2 ) ? 'Day' : 'Days' );
			}
            ?>
        </div>
        <div class="total_price">
            <?php
	            if($fields['order_days'] == 0 && PricePerHour::hasPerHour()) {
	                $priceTotal = PricePerHour::getPricePerHour($id) * $fields['order_hours'];
	                echo wc_price($priceTotal);
				} else if(PricePerHour::hasPerHour() || PriceForDatePeriod::hasDatePeriod() || (class_exists('DiscountByDays') && DiscountByDays::hasDiscount($id, $fields['order_days'])) || (class_exists('PriceForQuantityDays') && PriceForQuantityDays::hasFixedPrice($id, $fields['order_days']))) {
	                echo wc_price($product->get_price());
				} else {
					echo wc_price( $price * $orderDays );
                }
            ?>
        </div>
        <div class="daily_price">
            <?php echo sprintf( __( '%s/Daily', 'stm_motors_car_rental' ), wc_price( $price ) ); ?>
        </div>
    </div>
    <div class="rent-btn-wrap">
        <a href="#" data-invis="<?php echo esc_attr( $__vars['invis_id'] ) ?>" class="rent-now">
            <span class="open">
            <?php echo esc_html__( 'Rent Now!', 'stm_motors_car_rental' ); ?>
            </span>
            <span class="cancel">
            <?php echo esc_html__( 'Cancel', 'stm_motors_car_rental' ); ?>
            </span>
        </a>
    </div>
    <?php
}
?>