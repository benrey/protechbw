<p class="stm-mcr-lost-pass-success">
	<?php echo esc_html( apply_filters( 'woocommerce_lost_password_confirmation_message', esc_html__( 'A password reset email has been sent to the email address on file for your account, but may take several minutes to show up in your inbox. Please wait at least 10 minutes before attempting another reset.', 'stm_motors_car_rental' ) ) ); ?>
</p>